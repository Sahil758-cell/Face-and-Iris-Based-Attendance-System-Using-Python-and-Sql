from re import X
from tkinter import BOTTOM, HORIZONTAL, RIGHT, VERTICAL, Y, Label, StringVar, Tk, ttk, Button, Frame, LabelFrame, RIDGE  # Corrected to LabelFrame
from PIL import Image, ImageTk

class Student:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1500x790+0+0")
        self.root.title("Face_Recognition_System")

        #==============variables=========================
        self.var_dep = StringVar()
        self.var_course = StringVar()
        self.var_year = StringVar()
        self.var_semester = StringVar()
        self.var_std_id = StringVar()
        self.var_std_name = StringVar()
        self.var_div = StringVar()
        self.var_roll = StringVar()
        self.var_gender = StringVar()
        self.var_dob = StringVar()
        self.var_email = StringVar()
        self.var_phone = StringVar()
        self.var_address = StringVar()
        self.var_teacher = StringVar()
        self.var_Search = StringVar()
        self.var_teacher = StringVar()

        # Load and resize the first image
        img = Image.open(r"C:\Users\Tuf Gaming\Desktop\FaceRecognition System\Collage_image\images12.jpg")
        img = img.resize((500, 130), Image.Resampling.LANCZOS)  # Updated from Image.ANTIALIAS
        self.photoimg = ImageTk.PhotoImage(img)

        # Display the first image in a label
        f_lbl = Label(self.root, image=self.photoimg)
        f_lbl.place(x=0, y=0, width=500, height=130)

        # Load and resize the second image
        img1 = Image.open(r"C:\Users\Tuf Gaming\Desktop\FaceRecognition System\Collage_image\img2.jpg")
        img1 = img1.resize((500, 130), Image.Resampling.LANCZOS)  # Updated from Image.ANTIALIAS
        self.photoimg1 = ImageTk.PhotoImage(img1)

        # Display the second image in a label
        f_lbl1 = Label(self.root, image=self.photoimg1)
        f_lbl1.place(x=500, y=0, width=500, height=130)

        # Load and resize the third image
        img2 = Image.open(r"C:\Users\Tuf Gaming\Desktop\FaceRecognition System\Collage_image\gp2.jpg")
        img2 = img2.resize((500, 130), Image.Resampling.LANCZOS)  # Updated from Image.ANTIALIAS
        self.photoimg2 = ImageTk.PhotoImage(img2)

        # Display the third image in a label
        f_lbl2 = Label(self.root, image=self.photoimg2)
        f_lbl2.place(x=1000, y=0, width=500, height=130)

        # Load and resize the background image
        img3 = Image.open(r"C:\Users\Tuf Gaming\Desktop\FaceRecognition System\Collage_image\white.jpg")
        img3 = img3.resize((1530, 710), Image.Resampling.LANCZOS)  # Updated from Image.ANTIALIAS
        self.photoimg3 = ImageTk.PhotoImage(img3)

        # Display the background image in a label
        bg_image_label = Label(self.root, image=self.photoimg3)
        bg_image_label.place(x=0, y=130, width=1530, height=710)

        # Title label (centered the title)
        title_lbl = Label(bg_image_label, text="Student Management System", font=("times new roman", 35, "bold"), bg="white", fg="red")
        title_lbl.place(x=480, y=0, width=570, height=45)  # Adjusted to center the title

        # Create the main frame
        main_frame = Frame(bg_image_label, bd=2, bg="white")
        main_frame.place(x=20, y=50, width=1480, height=600)

        # Left label frame
        Left_frame = LabelFrame(main_frame, bd=2, relief=RIDGE, text="Student Details", font=("times new roman", 12, "bold"), bg="white", fg="blue")
        Left_frame.place(x=10, y=10, width=730, height=580)

        # Left label image
        img_left = Image.open(r"C:\Users\Tuf Gaming\Desktop\FaceRecognition System\Collage_image\group1.jpg")
        img_left = img_left.resize((550, 130), Image.Resampling.LANCZOS)  # Updated from Image.ANTIALIAS
        self.photoimg_left = ImageTk.PhotoImage(img_left)

        # Display the background image in a label inside the left frame
        left_bg_label = Label(Left_frame, image=self.photoimg_left)
        left_bg_label.place(x=5, y=0, width=720, height=130)

        # Current course information
        current_course_frame = LabelFrame(Left_frame, bd=2, bg="White", relief=RIDGE, text="Current Course information", font=("times new roman", 12, "bold"))
        current_course_frame.place(x=5, y=135, width=720, height=150)

        # Department
        dep_label = Label(current_course_frame, text="Department", font=("times new roman", 13, "bold"), bg="white")
        dep_label.grid(row=0, column=0, padx=10, sticky="W")

        dep_combo = ttk.Combobox(current_course_frame, textvariable=self.var_dep, font=("times new roman", 13, "bold"), width=20, state="read only")
        dep_combo["values"] = ("Select Department", "Computer", "IT", "Civil", "Mechanical")
        dep_combo.current(0)
        dep_combo.grid(row=0, column=1, padx=2, pady=10, sticky="W")

        # Course
        course_label = Label(current_course_frame, text="Course", font=("times new roman", 13, "bold"), bg="white")
        course_label.grid(row=0, column=2, padx=10, sticky="W")

        course_combo = ttk.Combobox(current_course_frame, textvariable=self.var_course, font=("times new roman", 13, "bold"), width=20, state="read only")
        course_combo["values"] = ("Select Course", "FE", "SE", "TE", "BE")
        course_combo.current(0)
        course_combo.grid(row=0, column=3, padx=2, pady=10, sticky="W")

        # Year
        year_label = Label(current_course_frame, text="Year", font=("times new roman", 13, "bold"), bg="white")
        year_label.grid(row=1, column=0, padx=10, sticky="W")

        year_combo = ttk.Combobox(current_course_frame, textvariable=self.var_year, font=("times new roman", 13, "bold"), width=20, state="read only")
        year_combo["values"] = ("Select Year", "2020-21", "2021-22", "2022-2023", "2023-2024", "2024-25")
        year_combo.current(0)
        year_combo.grid(row=1, column=1, padx=2, pady=10, sticky="W")

        # Semester
        semester_label = Label(current_course_frame, text="Semester", font=("times new roman", 13, "bold"), bg="white")
        semester_label.grid(row=1, column=2, padx=10, sticky="W")

        semester_combo = ttk.Combobox(current_course_frame, textvariable=self.var_semester, font=("times new roman", 13, "bold"), width=20, state="read only")
        semester_combo["values"] = ("Select Semester", "Semester-1", "Semester-2")
        semester_combo.current(0)
        semester_combo.grid(row=1, column=3, padx=2, pady=10, sticky="W")

        # Student Information
        Class_Student_frame = LabelFrame(Left_frame, bd=2, bg="White", relief=RIDGE, text=" Class Student Information", font=("times new roman", 12, "bold"))
        Class_Student_frame.place(x=5, y=250, width=720, height=300)

        # Student ID
        std_id_label = Label(Class_Student_frame, text="Student ID", font=("times new roman", 13, "bold"), bg="white")
        std_id_label.grid(row=0, column=0, padx=10,pady=5, sticky="W")

        std_id_entry = ttk.Entry(Class_Student_frame, textvariable=self.var_std_id, font=("times new roman", 13, "bold"), width=20)
        std_id_entry.grid(row=0, column=1, padx=10, pady=5, sticky="W")

        # Student Name
        name_label = Label(Class_Student_frame, text="Student Name", font=("times new roman", 13, "bold"), bg="white")
        name_label.grid(row=0, column=2, padx=10,pady=5, sticky="W")

        name_entry = ttk.Entry(Class_Student_frame, textvariable=self.var_std_name, font=("times new roman", 13, "bold"), width=20)
        name_entry.grid(row=0, column=3, padx=10, pady=5, sticky="W")

        # Class Division
        div_label = Label(Class_Student_frame, text="Class Division", font=("times new roman", 13, "bold"), bg="white")
        div_label.grid(row=1, column=0, padx=10,pady=5, sticky="W")

        div_entry = ttk.Entry(Class_Student_frame, textvariable=self.var_div, font=("times new roman", 13, "bold"), width=20)
        div_entry.grid(row=1, column=1, padx=10, pady=5, sticky="W")

        # Roll Number
        roll_label = Label(Class_Student_frame, text="Roll No.", font=("times new roman", 13, "bold"), bg="white")
        roll_label.grid(row=1, column=2, padx=10,pady=5, sticky="W")

        roll_entry = ttk.Entry(Class_Student_frame, textvariable=self.var_roll, font=("times new roman", 13, "bold"), width=20)
        roll_entry.grid(row=1, column=3, padx=10, pady=5, sticky="W")

        # Gender (Radio Buttons)
        gender_label = Label(Class_Student_frame, text="Gender", font=("times new roman", 13, "bold"), bg="white")
        gender_label.grid(row=2, column=0, padx=10, pady=10, sticky="W")

        gender_entry = ttk.Entry(Class_Student_frame, font=("times new roman", 13, "bold"), width=20)
        gender_entry.grid(row=2, column=1, padx=10, pady=5, sticky="W")
       

          # Date of Birth (DOB)
        dob_label = Label(Class_Student_frame, text="Date of Birth", font=("times new roman", 13, "bold"), bg="white")
        dob_label.grid(row=2, column=2, padx=10,pady=5, sticky="W")

        dob_entry = ttk.Entry(Class_Student_frame, textvariable=self.var_dob, font=("times new roman", 13, "bold"), width=20)
        dob_entry.grid(row=2, column=3, padx=10, pady=5, sticky="W")

        # Email
        email_label = Label(Class_Student_frame, text="Email", font=("times new roman", 13, "bold"), bg="white")
        email_label.grid(row=3, column=0, padx=10, pady=5, sticky="W")

        email_entry = ttk.Entry(Class_Student_frame, textvariable=self.var_email, font=("times new roman", 13, "bold"), width=20)
        email_entry.grid(row=3, column=1, padx=10, pady=5, sticky="W")

        # Phone Number
        phone_label = Label(Class_Student_frame, text="Phone No.", font=("times new roman", 13, "bold"), bg="white")
        phone_label.grid(row=3, column=2, padx=10,pady=5, sticky="W")

        phone_entry = ttk.Entry(Class_Student_frame, textvariable=self.var_phone, font=("times new roman", 13, "bold"), width=20)
        phone_entry.grid(row=3, column=3, padx=10, pady=5, sticky="W")

        # Address
        address_label = Label(Class_Student_frame, text="Address", font=("times new roman", 13, "bold"), bg="white")
        address_label.grid(row=4, column=0, padx=10,pady=5, sticky="W")

        address_entry = ttk.Entry(Class_Student_frame, textvariable=self.var_address, font=("times new roman", 13, "bold"), width=20)
        address_entry.grid(row=4, column=1, padx=10, pady=5, sticky="W")

        # Teacher Name
        teacher_label = Label(Class_Student_frame, text="Teacher Name", font=("times new roman", 13, "bold"), bg="white")
        teacher_label.grid(row=4, column=2, padx=10,pady=5, sticky="W")

        teacher_entry = ttk.Entry(Class_Student_frame, textvariable=self.var_teacher, font=("times new roman", 13, "bold"), width=20)
        teacher_entry.grid(row=4, column=3, padx=10, pady=5, sticky="W")

        # radio Buttons
        radiobtn1=ttk.Radiobutton(Class_Student_frame,text="Take Photo Sample",value="Yes")
        radiobtn1.grid(row=6,column=0,padx=10,pady=5,sticky="w")

        #radio button 2
        radiobtn2=ttk.Radiobutton(Class_Student_frame,text="No Photo Sample",value="No")
        radiobtn2.grid(row=6,column=1,padx=10,pady=5,sticky="w")

       # bbutton frame
        btn_frame=Frame(Class_Student_frame,bd=2,relief=RIDGE,bg="white")
        btn_frame.place(x=0,y=210,width=715,height=35)

        save_btn=Button(btn_frame,text="save",width=17,font=("times new roman", 13, "bold"), bg="blue",fg="white")
        save_btn.grid(row=0,column=0)

        #Update

        Update_btn=Button(btn_frame,text="Update",width=17,font=("times new roman", 13, "bold"), bg="blue",fg="white")
        Update_btn.grid(row=0,column=1)

        #Delete
        Delete_btn=Button(btn_frame,text="Delete",width=17,font=("times new roman", 13, "bold"), bg="blue",fg="white")
        Delete_btn.grid(row=0,column=2)

        #Reset
        Reset_btn=Button(btn_frame,text="Reset",width=17,font=("times new roman", 13, "bold"), bg="blue",fg="white")
        Reset_btn.grid(row=0,column=3)

        #Second Button
        btn_frame1=Frame(Class_Student_frame,bd=2,relief=RIDGE,bg="white")
        btn_frame1.place(x=0,y=245,width=715,height=30)

        save_btn=Button(btn_frame,text="save",width=17,font=("times new roman", 13, "bold"), bg="blue",fg="white")
        save_btn.grid(row=1,column=0)

        #Take photo button
        Take_Photo_btn=Button(btn_frame1,text="Take Photo Sample",width=35,font=("times new roman", 13, "bold"), bg="blue",fg="white")
        Take_Photo_btn.grid(row=1,column=0)
        #Update photo button 
        Update_Photo_btn=Button(btn_frame1,text="Update Photo Sample",width=35,font=("times new roman", 13, "bold"), bg="blue",fg="white")
        Update_Photo_btn.grid(row=1,column=1)
       
       #Right Frame
       
        Right_frame = LabelFrame(main_frame, bd=2, relief=RIDGE, text="Student Details", font=("times new roman", 12, "bold"), bg="white", fg="blue")
        Right_frame.place(x=750, y=10, width=730, height=580)

        # Right label image
        img_Right = Image.open(r"C:\Users\Tuf Gaming\Desktop\FaceRecognition System\Collage_image\group1.jpg")
        img_Right = img_Right.resize((550, 130), Image.Resampling.LANCZOS)  # Updated from Image.ANTIALIAS
        self.photoimg_Right = ImageTk.PhotoImage(img_Right)  # Corrected variable name

        # Display the image in a label inside the right frame
        Right_bg_label = Label(Right_frame, image=self.photoimg_Right)  # Use the correct variable
        Right_bg_label.place(x=5, y=0, width=720, height=130)

        #============Search System===========
        Search_frame = LabelFrame(Right_frame, bd=2, bg="White", relief=RIDGE, text=" Search System", font=("times new roman", 12, "bold"))
        Search_frame.place(x=5, y=135, width=710, height=70)

        Search_label = Label(Search_frame, text="Search By: ", font=("times new roman", 13, "bold"), bg="red",fg="white")
        Search_label.grid(row=0, column=0, padx=10,pady=5, sticky="W")
        
        Search_combo = ttk.Combobox(Search_frame, font=("times new roman", 13, "bold"), width=15, state="read only")
        Search_combo["values"] = ("Select","Roll_No", "Phone_No")
        Search_combo.current(0)
        Search_combo.grid(row=0, column=1, padx=2, pady=10, sticky="W")

        Search_entry = ttk.Entry(Search_frame, font=("times new roman", 13, "bold"), width=15)
        Search_entry.grid(row=0, column=2, padx=10, pady=5, sticky="W")

        #Button in Search frame
        Search_btn=Button(Search_frame,text="Search",width=12,font=("times new roman", 13, "bold"), bg="blue",fg="white")
        Search_btn.grid(row=0,column=3,padx=4)

        ShowAll_btn=Button(Search_frame,text="ShowAll",width=12,font=("times new roman", 13, "bold"), bg="blue",fg="white")
        ShowAll_btn.grid(row=0,column=4,padx=4)

        #=========================Table Frame===============



#=============================Function Declaration================================
    
if __name__ == "__main__":
    root = Tk()
    obj = Student(root)
    root.mainloop()



